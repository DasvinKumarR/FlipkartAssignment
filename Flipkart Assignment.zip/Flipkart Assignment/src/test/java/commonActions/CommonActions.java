package commonActions;

import static org.testng.Assert.assertEquals;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;


public class CommonActions {
	
	String dataValue;
	String text;
	public static String productTitle;
	
	public String getDataFromPropertyFile(String KeyValueNeeded) {
		try {
			Properties prop = new Properties();
			FileInputStream propertyFile = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/DatasetAndPropertyFiles/ConstantValues.properties");
			prop.load(propertyFile);
			dataValue = prop.getProperty(KeyValueNeeded);
		}catch (IOException e) {
			e.printStackTrace();
			Reporter.log("IO exception error occured");
			Assert.fail();
		}
		return dataValue;
	}
	
	public void validateText(WebDriver driver, String ActualText, String ExpectedText) {
		try {
			assertEquals(ActualText, ExpectedText);
		}catch (NoSuchElementException e) {
			e.printStackTrace();
			Reporter.log("Actual Value is different from Expected value");
			Assert.fail();
		}
	}
	
	public void enterText(WebDriver driver, WebElement ele, String text) {
		try {
			ExplicitWait(driver, ele);
			ele.sendKeys(text);
		}catch (NoSuchElementException e) {
			e.printStackTrace();
			Reporter.log("Element is not present in the webpage");
			Assert.fail();
		}
	}
	
	public String getText(WebDriver driver, WebElement ele) {
		try {
			ExplicitWait(driver, ele);
			text = ele.getText();
		}catch (NoSuchElementException e) {
			e.printStackTrace();
			Assert.fail();
		}catch (StaleElementReferenceException e) {
			
		}
		return text;
	}
	
	public void splitString(String text) {
		String[] title = text.split(" ");
		productTitle =  title[0]+" "+title[1]+" "+title[2]+" "+title[3];
	}
	
	public String productShortName() {
		return productTitle;
	}
	
	public void clickButton(WebDriver driver, WebElement ele) {
		try {
			ExplicitWait(driver, ele);
			ele.click();
		} catch(StaleElementReferenceException e) {
			
		}
		catch (NoSuchElementException e) {
			e.printStackTrace();
			Reporter.log("Element is not present in the webpage");
			Assert.fail();
		}catch (ElementClickInterceptedException e) {
			e.printStackTrace();
			Reporter.log("Element mentioned is not clickable");
			Assert.fail();
		}
	}
	
	public void pressEnterButton(WebDriver driver, WebElement ele) {
		try {
			ExplicitWait(driver, ele);
			ele.sendKeys(Keys.ENTER);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	public void switchTab(WebDriver driver, int tabCount) {
		
		ArrayList<String> win = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(win.get(tabCount));
 	}
	
	public void ExplicitWait(WebDriver driver, WebElement ele) {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
		wait.until(ExpectedConditions.visibilityOf(ele));
	}
	
	public void ExplicitWaitStaleElement(WebDriver driver, WebElement ele) {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
		wait.until(ExpectedConditions.stalenessOf(ele));
	}
	
	public void clickAction(WebDriver driver, WebElement ele) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(ele).click().perform();
		}catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		
	}
	
	//click button using java script
	public void clicButtonJS(WebDriver driver, WebElement ele) {
		ExplicitWait(driver, ele);
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", ele);
		}catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		
	}

}
