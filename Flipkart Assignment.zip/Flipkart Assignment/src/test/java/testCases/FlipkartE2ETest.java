package testCases;

import org.testng.annotations.Test;
import baseCofiguration.BaseConfig;
import commonActions.CommonActions;
import pages.CartPage;
import pages.FlipkartHomePage;
import pages.ProductPages;

public class FlipkartE2ETest extends BaseConfig {
	
	CommonActions act = new CommonActions();
	
	@Test
	public void BuyThinksE2E() {
		FlipkartHomePage FHome = new FlipkartHomePage(driver);
		ProductPages PP = new ProductPages(driver);
		CartPage CP = new CartPage(driver);
		//validate home page is loaded successfully
		FHome.ValidateTitle("title");
		//Enter and search product needed
		FHome.searchForProduct(act.getDataFromPropertyFile("productName"));
		//select product from the result
		FHome.selectProduct();
		//Switch to current tab
		FHome.swtichToProductTab(1);
		//Click add to cart button to add the product in cart
		PP.clickAddToCartButton();
		//click on cart to move to cart page
		PP.clickCartButton();
		//Validate selected product is added to cart
		CP.validateProductAddToCart();
		//click place order button
		CP.clickPlaceOrderButton();
		//Enter mobile number
		CP.EnterMobileNumber();
	}

}
