package baseCofiguration;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import commonActions.CommonActions;
import io.github.bonigarcia.wdm.WebDriverManager;


public class BaseConfig {
	
	public static WebDriver driver;
	private Properties prop = new Properties();
	CommonActions act = new CommonActions();
	
	
	public void initiateDriver() throws IOException {
		FileInputStream propertyFile = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/DatasetAndPropertyFiles/ConstantValues.properties");
		prop.load(propertyFile);
		switch (prop.getProperty("driver")) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			ChromeOptions ChromeOption  = new ChromeOptions();
			ChromeOption.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(ChromeOption);
			break;
		case "firefox":
			WebDriverManager.chromedriver().setup();
			FirefoxOptions FirefoxOption  = new FirefoxOptions();
			FirefoxOption.addArguments("--remote-allow-origins=*");
			driver = new FirefoxDriver(FirefoxOption);
			break;
		case "edge":
			WebDriverManager.chromedriver().setup();
			EdgeOptions EdgeOption  = new EdgeOptions();
			EdgeOption.addArguments("--remote-allow-origins=*");
			driver = new EdgeDriver(EdgeOption);
			break;

		default:
			System.out.println("Please metion valid driver name in property file, Thanks");
			break;
		}
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("URL"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

	}
	
	@BeforeTest
	public void StartUp() throws IOException {
		initiateDriver();
	}
	
	@AfterTest
	public void tearDown() {
		//driver.quit();
	}

}
