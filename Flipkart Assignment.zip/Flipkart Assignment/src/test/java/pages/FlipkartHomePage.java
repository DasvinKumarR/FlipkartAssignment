package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonActions.CommonActions;

public class FlipkartHomePage {
	
	WebDriver driver;
	CommonActions act = new CommonActions();
	
	public FlipkartHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	
	@FindBy(xpath = "//span[@role='button']")
	private WebElement closePopup;
	
	@FindBy (xpath = "//span[text()='Login']")
	private WebElement LoginButtonText;
	
	@FindBy(name = "q")
	private WebElement searchTextbox;
	
	@FindBy(xpath = "//button[contains(@title,'Search for Products')]")
	private WebElement searchButton;
	
	@FindBy(xpath = "(//a[contains(@rel,'noopener')])[1]")
	private WebElement selectFirstProduct;

	public void closePopup() {
		closePopup.click();
	}
	
	public void ValidateTitle(String text) {
		String ActualText = driver.getTitle();
		act.validateText(driver, ActualText, act.getDataFromPropertyFile(text));
	}
	
	public void searchForProduct(String text) {
		act.enterText(driver, searchTextbox, text);
		act.pressEnterButton(driver, searchTextbox);
	}
	
	public void selectProduct() {
		act.clickButton(driver, selectFirstProduct);
	}
	
	public void swtichToProductTab(int tabCount) {
		act.switchTab(driver, tabCount);
		try {
			Thread.sleep(2000);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
