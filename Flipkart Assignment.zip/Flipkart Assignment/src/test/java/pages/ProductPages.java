package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonActions.CommonActions;

public class ProductPages {

	WebDriver driver;
	CommonActions act = new CommonActions();
	public String productTitle = null;
	
	public ProductPages(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	
	@FindBy(xpath = "//button[text()='Add to cart']")
	private WebElement AddToCartButton;
	
	@FindBy(xpath = "//span[text()='Cart']//ancestor::a")
	private WebElement cartButton;
	
	@FindBy(xpath = "//h1//span")
	private WebElement productName;
	
	public void getProductName() {
		act.ExplicitWait(driver, productName);
		String text =  act.getText(driver, productName);
		act.splitString(text);
	}
	
	public void clickAddToCartButton() {
		getProductName();
		act.clickButton(driver, AddToCartButton);
	}
	
	public void clickCartButton() {
		act.clickButton(driver, cartButton);
	}
	
}
