package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonActions.CommonActions;

public class CartPage {
	
	WebDriver driver;
	CommonActions act = new CommonActions();
	String productTitleActual;
	
	public CartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	
	@FindBy(xpath = "(//div[text()='Total Amount']//following::span)[1]")
	private WebElement totalAmountPrice;
	
	@FindBy(xpath = "(//span[text()='Place Order'])//ancestor::button")
	private WebElement placeOrderButton;
	
	@FindBy(xpath = "//input[@type='text']")
	private WebElement mobileNumberTextbox;
	
	public void validateProductAddToCart() {
		String productAddedName = driver.findElement(By.xpath("//a[contains(text(),'"+act.productShortName()+"')]")).getText();
		String[] title = productAddedName.split(" ");
		productTitleActual =  title[0]+" "+title[1]+" "+title[2]+" "+title[3];
		act.validateText(driver, productTitleActual, act.productShortName());
	}
	
	public void clickPlaceOrderButton() {
		act.ExplicitWait(driver, placeOrderButton);
		act.clicButtonJS(driver, placeOrderButton);
	}
	
	public void EnterMobileNumber() {
		act.ExplicitWait(driver, mobileNumberTextbox);
		act.enterText(driver, mobileNumberTextbox, act.getDataFromPropertyFile("mobileNumber"));
		act.pressEnterButton(driver, mobileNumberTextbox);
	}
	
	

}
